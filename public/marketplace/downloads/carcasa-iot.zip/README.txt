ProtoLab — Carcasa IoT
Material de referencia del prototipo académico Test & Show de GEN 2.

OBJ corresponde a la geometría de referencia usada en el catálogo.
MTL contiene únicamente los colores de visualización.
Al importar, interpretar las coordenadas como milímetros con Z vertical.
Dimensiones y escala aproximadas. La malla representa el conjunto visual.
No se han comprobado encajes, tolerancias, resistencia ni aptitud para fabricación.

Licencia de este recurso: uso personal y académico no comercial.
Puedes abrir y modificar el archivo para aprender o evaluar la geometría.
Su venta o redistribución comercial requiere autorización de ProtoLab.
